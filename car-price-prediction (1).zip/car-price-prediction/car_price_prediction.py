"""
Car Price Prediction – Linear Regression & Lasso Regression
============================================================
Full pipeline: load → EDA → encode → train → evaluate → plots → sample prediction
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Lasso
from sklearn import metrics
import warnings

warnings.filterwarnings("ignore")
sns.set_theme(style="whitegrid")


def load_dataset():
    if os.path.exists("car data.csv"):
        print("Loading: car data.csv")
        return pd.read_csv("car data.csv")
    if os.path.exists("/content/car data.csv"):
        return pd.read_csv("/content/car data.csv")
    raise FileNotFoundError("car data.csv not found in project folder.")


def main():
    print("=" * 60)
    print("  Car Price Prediction | Linear Regression + Lasso")
    print("=" * 60)

    # 1. Load
    print("\n[1/8] Loading dataset...")
    car_dataset = load_dataset()
    print(f"Shape: {car_dataset.shape}")
    print(car_dataset.head())
    print("\nInfo:")
    print(car_dataset.info())
    print("\nMissing values:")
    print(car_dataset.isnull().sum())

    # 2. Categorical distributions
    print("\n[2/8] Categorical distributions...")
    print("Fuel_Type:\n", car_dataset["Fuel_Type"].value_counts())
    print("Seller_Type:\n", car_dataset["Seller_Type"].value_counts())
    print("Transmission:\n", car_dataset["Transmission"].value_counts())

    fig, axes = plt.subplots(1, 3, figsize=(14, 4))
    sns.countplot(x="Fuel_Type", data=car_dataset, ax=axes[0], palette="Blues")
    axes[0].set_title("Fuel Type")
    sns.countplot(x="Seller_Type", data=car_dataset, ax=axes[1], palette="Greens")
    axes[1].set_title("Seller Type")
    sns.countplot(x="Transmission", data=car_dataset, ax=axes[2], palette="Oranges")
    axes[2].set_title("Transmission")
    plt.tight_layout()
    plt.savefig("categorical_distributions.png", dpi=150)
    print("Saved: categorical_distributions.png")
    plt.close()

    # 3. Price distributions & relationships
    print("\n[3/8] Price & relationship plots...")
    plt.figure(figsize=(8, 5))
    sns.histplot(car_dataset["Selling_Price"], kde=True, color="steelblue")
    plt.title("Selling Price Distribution")
    plt.xlabel("Selling Price (lakhs)")
    plt.tight_layout()
    plt.savefig("selling_price_distribution.png", dpi=150)
    print("Saved: selling_price_distribution.png")
    plt.close()

    plt.figure(figsize=(8, 5))
    sns.scatterplot(
        x="Present_Price",
        y="Selling_Price",
        hue="Fuel_Type",
        data=car_dataset,
        alpha=0.7,
    )
    plt.title("Present Price vs Selling Price")
    plt.tight_layout()
    plt.savefig("present_vs_selling_price.png", dpi=150)
    print("Saved: present_vs_selling_price.png")
    plt.close()

    plt.figure(figsize=(8, 5))
    sns.boxplot(x="Year", y="Selling_Price", data=car_dataset)
    plt.xticks(rotation=45)
    plt.title("Year vs Selling Price")
    plt.tight_layout()
    plt.savefig("year_vs_selling_price.png", dpi=150)
    print("Saved: year_vs_selling_price.png")
    plt.close()

    # 4. Encode categoricals
    print("\n[4/8] Encoding categorical columns...")
    car_dataset.replace(
        {
            "Fuel_Type": {"Petrol": 0, "Diesel": 1, "CNG": 2},
            "Seller_Type": {"Dealer": 0, "Individual": 1},
            "Transmission": {"Manual": 0, "Automatic": 1},
        },
        inplace=True,
    )
    print(car_dataset.head())

    # Correlation heatmap (numeric only)
    plt.figure(figsize=(10, 8))
    corr = car_dataset.select_dtypes(include=[np.number]).corr()
    sns.heatmap(
        corr,
        annot=True,
        fmt=".2f",
        cmap="coolwarm",
        square=True,
        cbar=True,
    )
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig("correlation_heatmap.png", dpi=150)
    print("Saved: correlation_heatmap.png")
    plt.close()

    # 5. Split
    print("\n[5/8] Train / Test split (90/10)...")
    X = car_dataset.drop(["Car_Name", "Selling_Price"], axis=1)
    Y = car_dataset["Selling_Price"]
    X_train, X_test, Y_train, Y_test = train_test_split(
        X, Y, test_size=0.1, random_state=2
    )
    print(f"Train: {X_train.shape} | Test: {X_test.shape}")

    # 6. Linear Regression
    print("\n[6/8] Training Linear Regression...")
    lin_model = LinearRegression()
    lin_model.fit(X_train, Y_train)

    train_pred_lin = lin_model.predict(X_train)
    test_pred_lin = lin_model.predict(X_test)

    r2_train_lin = metrics.r2_score(Y_train, train_pred_lin)
    r2_test_lin = metrics.r2_score(Y_test, test_pred_lin)
    mae_train_lin = metrics.mean_absolute_error(Y_train, train_pred_lin)
    mae_test_lin = metrics.mean_absolute_error(Y_test, test_pred_lin)

    print(f"  Train R²: {r2_train_lin:.4f} | MAE: {mae_train_lin:.4f}")
    print(f"  Test  R²: {r2_test_lin:.4f} | MAE: {mae_test_lin:.4f}")

    plt.figure(figsize=(7, 6))
    plt.scatter(Y_test, test_pred_lin, alpha=0.7, color="steelblue")
    plt.plot(
        [Y_test.min(), Y_test.max()],
        [Y_test.min(), Y_test.max()],
        "r--",
        lw=2,
    )
    plt.xlabel("Actual Price")
    plt.ylabel("Predicted Price")
    plt.title(f"Linear Regression – Actual vs Predicted (R²={r2_test_lin:.3f})")
    plt.tight_layout()
    plt.savefig("linear_actual_vs_predicted.png", dpi=150)
    print("Saved: linear_actual_vs_predicted.png")
    plt.close()

    # 7. Lasso Regression
    print("\n[7/8] Training Lasso Regression...")
    lasso_model = Lasso()
    lasso_model.fit(X_train, Y_train)

    train_pred_lasso = lasso_model.predict(X_train)
    test_pred_lasso = lasso_model.predict(X_test)

    r2_train_lasso = metrics.r2_score(Y_train, train_pred_lasso)
    r2_test_lasso = metrics.r2_score(Y_test, test_pred_lasso)
    mae_train_lasso = metrics.mean_absolute_error(Y_train, train_pred_lasso)
    mae_test_lasso = metrics.mean_absolute_error(Y_test, test_pred_lasso)

    print(f"  Train R²: {r2_train_lasso:.4f} | MAE: {mae_train_lasso:.4f}")
    print(f"  Test  R²: {r2_test_lasso:.4f} | MAE: {mae_test_lasso:.4f}")

    plt.figure(figsize=(7, 6))
    plt.scatter(Y_test, test_pred_lasso, alpha=0.7, color="seagreen")
    plt.plot(
        [Y_test.min(), Y_test.max()],
        [Y_test.min(), Y_test.max()],
        "r--",
        lw=2,
    )
    plt.xlabel("Actual Price")
    plt.ylabel("Predicted Price")
    plt.title(f"Lasso Regression – Actual vs Predicted (R²={r2_test_lasso:.3f})")
    plt.tight_layout()
    plt.savefig("lasso_actual_vs_predicted.png", dpi=150)
    print("Saved: lasso_actual_vs_predicted.png")
    plt.close()

    # 8. Comparison + sample prediction
    print("\n[8/8] Model comparison & sample prediction...")
    comparison = pd.DataFrame(
        {
            "Model": ["Linear Regression", "Lasso Regression"],
            "Train R²": [r2_train_lin, r2_train_lasso],
            "Test R²": [r2_test_lin, r2_test_lasso],
            "Train MAE": [mae_train_lin, mae_train_lasso],
            "Test MAE": [mae_test_lin, mae_test_lasso],
        }
    )
    print("\n" + comparison.to_string(index=False))

    # Sample prediction (first test row)
    sample = X_test.iloc[[0]]
    actual = Y_test.iloc[0]
    pred_lin = lin_model.predict(sample)[0]
    pred_lasso = lasso_model.predict(sample)[0]
    print("\n--- Sample Prediction ---")
    print(f"Features:\n{sample.to_string(index=False)}")
    print(f"Actual Selling Price : {actual:.2f}")
    print(f"Linear Prediction    : {pred_lin:.2f}")
    print(f"Lasso Prediction     : {pred_lasso:.2f}")

    print("\n" + "=" * 60)
    print("Done! Generated plots:")
    print("  - categorical_distributions.png")
    print("  - selling_price_distribution.png")
    print("  - present_vs_selling_price.png")
    print("  - year_vs_selling_price.png")
    print("  - correlation_heatmap.png")
    print("  - linear_actual_vs_predicted.png")
    print("  - lasso_actual_vs_predicted.png")
    print("=" * 60)


if __name__ == "__main__":
    main()
